package lab5;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import java.text.SimpleDateFormat;
import java.util.ArrayList;

import javax.swing.JButton;
import javax.swing.JCheckBox;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTabbedPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.border.MatteBorder;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;
import javax.swing.table.DefaultTableModel;

import lab5DatabaseLayered.Book;
import lab5DatabaseLayered.Borrower;
import lab5DatabaseLayered.Record;


public class Presentation_Layered extends JFrame {
	
	private final String[] bookColumns = {"Title", "Author", "Genre", "Available"};
    private final String[] borrowerColumns = {"Name", "Address", "Email", "Phone","BorrowedBook"};
    private final String[] recordColumns = { "Book Name", "Borrower Name"};

    private JTabbedPane tabbedPane;
    private JTable bookTable;
    private JTable borrowerTable;
    private JTable recordTable;

    // Add UI components
    private JTextField booktitleField;
    private JTextField nameField;
    private JTextField emailField;
    private JTextField phoneField;
    private JTextField addresssField;
    private JTextField authorField;
    private JTextField genreField;
    private JCheckBox availableField;
	private JTextField bookNameField;
	private JTextField borrowerNameField;
	private JTextField deleteBookField;
	private JTextField deleteBorrowerField;
	private JTextField deletecheckoutField;
    public  Presentation_Layered() {
    	getContentPane().setBackground(new Color(221, 161, 94));
    	ArrayList<Book> listofBooks= new  ArrayList<Book>();
    	ArrayList<String> listofBorrowedBooks= new ArrayList<String>();
    	ArrayList<Borrower> listofBorrower=new ArrayList<Borrower>();
    	ArrayList<Record> listofRecord = new ArrayList<Record>();

    	BusinessLayer busLayer = new BusinessLayer(listofBooks, listofBorrowedBooks, listofBorrower, listofRecord);

        DefaultTableModel bookModel = new DefaultTableModel(bookColumns, 0);
        bookTable = new JTable(bookModel);
        
        DefaultTableModel borrowerModel = new DefaultTableModel(borrowerColumns, 0);
        borrowerTable = new JTable(borrowerModel);

        DefaultTableModel checkoutModel = new DefaultTableModel(recordColumns, 0);
        recordTable = new JTable(checkoutModel);

//        Database.refreshTables(bookModel,borrowerModel,checkoutModel);
        busLayer.showTable(bookModel, borrowerModel, checkoutModel);
        
        
        tabbedPane = new JTabbedPane();
        tabbedPane.addTab("Books", new JScrollPane(bookTable));
        tabbedPane.addTab("Borrowers", new JScrollPane(borrowerTable));
        tabbedPane.addTab("Records", new JScrollPane(recordTable));

        // Book input Panel
        booktitleField = new JTextField(20);
        authorField = new JTextField(20);
        genreField = new JTextField(20);
        
        availableField = new JCheckBox("Available");
        deleteBookField = new JTextField();
        JButton addBookButton = new JButton("Add Book");
        JButton remBookButton = new JButton("Remove Book");
        JPanel bookPanel = new JPanel(new GridLayout(0,2));
        bookPanel.setBorder(new MatteBorder(5, 5, 5, 5, (Color) new Color(0, 0, 0)));
        bookPanel.add(new JLabel("Title:"));
        bookPanel.add(booktitleField);
        bookPanel.add(new JLabel("Author:"));
        bookPanel.add(authorField);
        bookPanel.add(new JLabel("Genre:"));
        bookPanel.add(genreField);
        bookPanel.add(new JLabel("Available:"));
        bookPanel.add(availableField);
        bookPanel.add(new JLabel(""));
        bookPanel.add(addBookButton);
        bookPanel.add(remBookButton);
        bookPanel.add(deleteBookField);
        addBookButton.addActionListener(new ActionListener() {
            @Override
        // You should implement the add book action here by getting the Title, author, genre... 
            public void actionPerformed(ActionEvent e) {
            	busLayer.addBooks(booktitleField.getText(), authorField.getText(), genreField.getText(), true);
            	System.out.println("Add success");
            	System.out.println(listofBooks);
            	busLayer.showTable(bookModel, borrowerModel, checkoutModel);
//            try {
//            	
//          	
//           	Database.addBook(booktitleField.getText(),
//           			authorField.getText(),
//          			genreField.getText(),
//           			pubDateField.getText(),
//          			isbnField.getText(),
//              		true
//           		);
//            
//           	Database.refreshTables(bookModel, borrowerModel, checkoutModel);
//                JOptionPane.showMessageDialog(addBookButton, "Book added successfully.");
//	        } catch (SQLException e1) {
//	            e1.printStackTrace();
//	            JOptionPane.showMessageDialog(addBookButton, "Error adding book. Please try again.");
//	        }
            }

			
        });
        
        
        remBookButton.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        		busLayer.delBooks(deleteBookField.getText());
        		System.out.println(deleteBookField.getText());
        		busLayer.showTable(bookModel, borrowerModel, checkoutModel);
       // You should implement the remove book action here by getting the id
      	
//        		try {
//					Database.delete("books", deleteBookField.getText());
//		            JOptionPane.showMessageDialog(remBookButton, "Book deleted successfully");
//	            	Database.refreshTables(bookModel, borrowerModel, checkoutModel);
//
//				} catch (SQLException e1) {
//		            JOptionPane.showMessageDialog(remBookButton, "Error deleting book. Please try again.");
//
//					e1.printStackTrace();
//				}
        	}
        });

        
        
//        Borrower input Panel
        JButton btnAddBorrower = new JButton("Add");
        JButton btnRemBorrower = new JButton("Remove");
        nameField = new JTextField();
        emailField = new JTextField();
        phoneField = new JTextField();
        addresssField = new JTextField();
        deleteBorrowerField = new JTextField();
        JPanel borrowerPanel= new JPanel(new GridLayout(0,2));
        borrowerPanel.setBorder(new MatteBorder(5, 5, 5, 5, (Color) new Color(0, 0, 0)));
        borrowerPanel.add(new JLabel("Name:"));
        borrowerPanel.add(nameField);
        borrowerPanel.add(new JLabel("Address:"));
        borrowerPanel.add(addresssField);
        borrowerPanel.add(new JLabel("Email:"));
        borrowerPanel.add(emailField);
        borrowerPanel.add(new JLabel("Phone:"));
        borrowerPanel.add(phoneField);
        borrowerPanel.add(new JLabel(""));
        borrowerPanel.add(btnAddBorrower);
        borrowerPanel.add(btnRemBorrower);
        borrowerPanel.add(deleteBorrowerField);
        btnAddBorrower.addActionListener(new ActionListener() {
			
			@Override
			// You should implement the borrow book action here by getting the name, email,phone,address...   
			public void actionPerformed(ActionEvent e) {
				busLayer.addBorrower(nameField.getText(), addresssField.getText(), emailField.getText(), phoneField.getText(), listofBorrowedBooks);
				busLayer.showTable(bookModel, borrowerModel, checkoutModel);
//				try {
//					Database.addBorrower(nameField.getText(),
//										emailField.getText(),
//										phoneField.getText(),
//										addresssField.getText());
//	                JOptionPane.showMessageDialog(btnAddBorrower, "Borrower added successfully.");
//	            	Database.refreshTables(bookModel, borrowerModel, checkoutModel);
//
//				} catch (SQLException e1) {
//		            JOptionPane.showMessageDialog(btnAddBorrower, "Error adding borrower. Please try again.");
//					e1.printStackTrace();
//					
//				}
				
			}
		});
        btnRemBorrower.addActionListener(new ActionListener() {
        	// You should implement the delete borrow book action here by getting the Id
		       	
			@Override
			public void actionPerformed(ActionEvent e) {
				busLayer.delBorrower(deleteBorrowerField.getText());
				busLayer.showTable(bookModel, borrowerModel, checkoutModel);
//				try {
//					Database.delete("borrowers", deleteBorrowerField.getText());
//	                JOptionPane.showMessageDialog(btnRemBorrower, "Borrower deleted successfully.");
//	            	Database.refreshTables(bookModel, borrowerModel, checkoutModel);
//
//				} catch (SQLException e1) {
//	                JOptionPane.showMessageDialog(btnRemBorrower, "Error deleting Borrower.Please try again");
//					e1.printStackTrace();
//				}
				
			}
		});
        
//        checkout input Panel
        
        JButton btnAddrecord = new JButton("Add");
        JButton btnRemrecord = new JButton("Remove");
        bookNameField = new JTextField();
        borrowerNameField = new JTextField(); 
        deletecheckoutField = new JTextField();
        JPanel recordPanel= new JPanel(new GridLayout(0,2));
        recordPanel.setBorder(new MatteBorder(5, 5, 5, 5, (Color) new Color(0, 0, 0)));
        recordPanel.add(new JLabel("Book Name:"));
        recordPanel.add(bookNameField);
        recordPanel.add(new JLabel("Borrower Name:"));
        recordPanel.add(borrowerNameField);
        recordPanel.add(btnAddrecord);
        recordPanel.add(btnRemrecord);
        recordPanel.add(deletecheckoutField);
        btnAddrecord.addActionListener(new ActionListener() {
			
			@Override
			// You should implement the Add book checkout action here by getting the id
		 
			public void actionPerformed(ActionEvent e) {
				busLayer.addRecord(borrowerNameField.getText(),bookNameField.getText());
				busLayer.showTable(bookModel, borrowerModel, checkoutModel);
//				try {
//					Database.addCheckout(bookIDField.getText(), 
//										borrowerIDField.getText(),
//										checkoutDateField.getText(),
//										dueDateField.getText(),
//										returnDateField.getText());
//					Database.refreshTables(bookModel, borrowerModel, checkoutModel);
//				} catch (SQLException e1) {
//		            JOptionPane.showMessageDialog(addBookButton, "Error adding checkouts. Please try again.");
//					e1.printStackTrace();
//				}
				
			}
		});
        btnRemrecord.addActionListener(new ActionListener() {
			
			@Override
			// You should implement the delete book action here by getting the id
		      
			public void actionPerformed(ActionEvent e) {
				busLayer.delRecord(deletecheckoutField.getText());;
				busLayer.showTable(bookModel, borrowerModel, checkoutModel);
//				try {
//					Database.delete("checkouts", deletecheckoutField.getText());
//	                JOptionPane.showMessageDialog(btnRemcheckout, "Checkout deleted successfully.");
//	            	Database.refreshTables(bookModel, borrowerModel, checkoutModel);
//
//				} catch (SQLException e1) {
//	                JOptionPane.showMessageDialog(btnRemcheckout, "Error deleting Checkout.Please try again");
//					e1.printStackTrace();
//				}
				
			}
		});
     // You don't have to change anything below
     // add a change listener to the tabbed pane to change the input panel accordingly
        tabbedPane.addChangeListener(new ChangeListener() {
            public void stateChanged(ChangeEvent e) {
                // get the index of the selected tab
                int selectedIndex = tabbedPane.getSelectedIndex();
                if(tabbedPane.getTitleAt(selectedIndex) == "Books") {
                	getContentPane().removeAll();
                	getContentPane().add(bookPanel, BorderLayout.NORTH);
         	        getContentPane().add(tabbedPane, BorderLayout.CENTER);
         	        
                }
                if(tabbedPane.getTitleAt(selectedIndex) == "Borrowers") {
                	getContentPane().removeAll();
                	getContentPane().add(borrowerPanel, BorderLayout.NORTH);
         	        getContentPane().add(tabbedPane, BorderLayout.CENTER);
         	       
                }
                if(tabbedPane.getTitleAt(selectedIndex) == "Records") {
                	getContentPane().removeAll();
                	getContentPane().add(recordPanel, BorderLayout.NORTH);
         	        getContentPane().add(tabbedPane, BorderLayout.CENTER);
                }
                repaint();
            }
            
        });
     // You don't have to change anything here
        // Add components to JFrame
        getContentPane().add(bookPanel, BorderLayout.NORTH);
        getContentPane().add(tabbedPane, BorderLayout.CENTER);

        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(800, 600);
        setLocationRelativeTo(null);
        setTitle("Library Management System");
        setVisible(true);
    }
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		new Presentation_Layered();
	}

}
