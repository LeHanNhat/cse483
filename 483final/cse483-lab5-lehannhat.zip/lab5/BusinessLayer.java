package lab5;




import java.util.ArrayList;

import javax.swing.table.DefaultTableModel;

import lab5DatabaseLayered.Book;
import lab5DatabaseLayered.Borrower;
import lab5DatabaseLayered.Record;

public class BusinessLayer {
	
	ArrayList<Book> listofBooks;
	ArrayList<String> listofBorrowedBooks;
	ArrayList<Borrower> listofBorrower;
	ArrayList<Record> listofRecord;
	
	public BusinessLayer(ArrayList<Book> listofBooks, ArrayList<String> listofBorrowedBooks,
			ArrayList<Borrower> listofBorrower, ArrayList<Record> listofRecord) {
		
		this.listofBooks = listofBooks;
		this.listofBorrowedBooks = listofBorrowedBooks;
		this.listofBorrower = listofBorrower;
		this.listofRecord = listofRecord;
	}
	public void addBooks(String title, String author,String genre, boolean available) {
			Book book = new Book(title, author, genre, available);
			this.listofBooks.add(book);
	}
	
	public void addBorrower(String name,String address, String email, String phoneNumber, ArrayList<String> borrowedBooks) {
			Borrower borrower = new Borrower(name,address, email, phoneNumber, borrowedBooks);
			this.listofBorrower.add(borrower);
			
	}
	
	public void addRecord(String name, String bookName) {
			Record record = new Record(bookName, name);
			this.listofRecord.add(record);
			
	}
    public void delBooks(String name) {
    	
		for	(int i =0 ; i < this.listofBooks.size(); i++ ) {
			if (this.listofBooks.get(i).getTitle().equals(name)) {
				this.listofBooks.remove(i);
				
			}
		}
    }
    public void delBorrower(String name) {
    	for	(int i =0 ; i < this.listofBorrower.size(); i++ ) {
			if (this.listofBorrower.get(i).getName().equals(name)) {
				this.listofBorrower.remove(i);
			}
		}
    	
    }
    public void delRecord(String name) {
    	for	(int i =0 ; i < this.listofRecord.size(); i++ ) {
			if (this.listofRecord.get(i).getBookName().equals(name)) {
				this.listofRecord.remove(i);
			}
		}
    }
	
	public void showTable(DefaultTableModel bookModel, DefaultTableModel borrowerModel, DefaultTableModel RecordModel) {
			bookModel.setRowCount(0);
			try {
				Object bookData[] = new Object[4]; 
        		
	            for (int i=0; i < this.listofBooks.size();i++) {
	            	bookData[0] = this.listofBooks.get(i).getTitle();
	            	bookData[1] = this.listofBooks.get(i).getAuthor();
	            	bookData[2] = this.listofBooks.get(i).getGenre();
	            	bookData[3] = this.listofBooks.get(i).isAvailableQuality(); 
	                bookModel.addRow(bookData);
	            }
			} catch (Exception e) {
				// TODO: handle exception
				System.out.println(e);
			}
			
			borrowerModel.setRowCount(0);
			try {
				Object borrowerData[] = new Object[5]; 
        		
	            for (int i=0; i < this.listofBorrower.size();i++) {
	            	borrowerData[0] = this.listofBorrower.get(i).getName();
	            	borrowerData[1] = this.listofBorrower.get(i).getAddress();
	            	borrowerData[2] = this.listofBorrower.get(i).getEmail();
	            	borrowerData[3] = this.listofBorrower.get(i).getPhoneNumber(); 
	            	borrowerModel.addRow(borrowerData);
	            }
			} catch (Exception e) {
				// TODO: handle exception
				System.out.println(e);
			}
			
			RecordModel.setRowCount(0);
			try {
				Object recordData[] = new Object[2]; 
        		
	            for (int i=0; i < this.listofRecord.size();i++) {
	            	recordData[0] = this.listofRecord.get(i).getBookName();
	            	recordData[1] = this.listofRecord.get(i).getBorrowerName();
	            	
	            	RecordModel.addRow(recordData);
	            }
			} catch (Exception e) {
				// TODO: handle exception
				System.out.println(e);
			}
            
        
	}
	
	
	
	
}
