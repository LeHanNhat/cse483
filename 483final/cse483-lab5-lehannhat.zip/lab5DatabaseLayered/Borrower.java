package lab5DatabaseLayered;

import java.util.ArrayList;
import lab5DatabaseLayered.Book;
public class Borrower {
	private String name;
	private String address;
	private String email;
	private String phoneNumber;
	private ArrayList<String> listofBorrowedBooks;
	
	
	
	
	public Borrower(String name,String address, String email, String phoneNumber, ArrayList<String> borrowedBooks) {
		this.name = name;
		this.address = address;
		this.email = email;
		this.phoneNumber = phoneNumber;
		this.listofBorrowedBooks = borrowedBooks;
	}


	

	public String getName() {
		return name;
	}




	public String getAddress() {
		return address;
	}




	public void setAddress(String address) {
		this.address = address;
	}




	public void setName(String name) {
		this.name = name;
	}




	public String getEmail() {
		return email;
	}




	public void setEmail(String email) {
		this.email = email;
	}




	public String getPhoneNumber() {
		return phoneNumber;
	}




	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}




	public ArrayList<String> getBorrowedBooks() {
		return listofBorrowedBooks;
	}




	public void setBorrowedBooks(ArrayList<String> borrowedBooks) {
		this.listofBorrowedBooks = borrowedBooks;
	}




	public void addBorrowedBooks(String bookName) {
		this.listofBorrowedBooks.add(bookName);
	}
	
}
