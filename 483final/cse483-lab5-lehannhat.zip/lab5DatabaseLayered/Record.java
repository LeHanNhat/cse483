package lab5DatabaseLayered;

import java.util.ArrayList;

public class Record {
	private String borrowerName;
	private String bookName;
	public Record( String bookName,String borrowerName) {
		
		this.borrowerName = borrowerName;
		this.bookName = bookName;
	}
	public String getBorrowerName() {
		return borrowerName;
	}
	public void setBorrowerName(String borrowerName) {
		this.borrowerName = borrowerName;
	}
	public String getBookName() {
		return bookName;
	}
	public void setBookName(String bookName) {
		this.bookName = bookName;
	}
	
	
}
