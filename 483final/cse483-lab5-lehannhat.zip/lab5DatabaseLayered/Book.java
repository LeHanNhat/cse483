package lab5DatabaseLayered;

public class Book {
	private String title;
	private String author;
	private String genre;
	private boolean availableQuality;
	public Book(String title, String author, String genre, boolean availableQuality) {
		this.title = title;
		this.author = author;
		this.genre = genre;
		this.availableQuality = availableQuality;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getAuthor() {
		return author;
	}
	public void setAuthor(String author) {
		this.author = author;
	}
	public String getGenre() {
		return genre;
	}
	public void setGenre(String genre) {
		this.genre = genre;
	}
	public boolean isAvailableQuality() {
		return availableQuality;
	}
	public void setAvailableQuality(boolean availableQuality) {
		this.availableQuality = availableQuality;
	}
	
	
	
	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return this.title + " " + this.author+ " "+ this.genre + " " + this.availableQuality;
	}
	
	
	
	
}
