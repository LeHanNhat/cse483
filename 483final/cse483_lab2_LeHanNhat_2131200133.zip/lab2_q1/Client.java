package lab2_q1;

import java.util.ArrayList;

public class Client {
	private Manager manager;

	public Client() {
		
	}
	public void setManager(Manager manager) {
		this.manager = manager;
	}
	public void sendRequest(String request, ArrayList<Employee> allEmployees) {
		this.manager.filterRequest(request,allEmployees);
	}
}
