package lab2_q1;

import java.util.ArrayList;

public class DepartmentFilter implements Filtered {

	

	@Override
	public void meetFiltered(ArrayList<Employee> employees, String request) {
		// TODO Auto-generated method stub
		ArrayList<Employee> departmentEm = new ArrayList<Employee>();
		for (Employee em : employees) {
			if(em.getDepartment()==request) {
				departmentEm.add(em);
			}
		}
		System.out.println(departmentEm);
	}

}
