package lab2_q1;


import java.util.ArrayList;

public class ExperienceFilter implements Filtered{

	@Override
	public void meetFiltered(ArrayList<Employee> employees, String request) {
		// TODO Auto-generated method stub
		ArrayList<Employee> exEm = new ArrayList<Employee>();
		for (Employee em : employees) {
			if(em.getExperience()==request) {
				exEm.add(em);
			}
		}
		System.out.println(exEm);
	}

}
