package lab2_q1;

import java.util.ArrayList;

public class Main {
	public static void main(String[] args) {
		Employee e1 = new Employee("nhat", "t", "nv", "5nam", "1000", "0");
		Employee e2 = new Employee("bao", "v", "nv", "4nam", "1000", "1");
		Employee e3 = new Employee("duy", "t", "s", "5nam", "3000", "0");
		
		ArrayList<Employee> employees = new ArrayList<Employee>();
		employees.add(e1);
		employees.add(e2);
		employees.add(e3);
		
		Target target = new Target();
		Manager manager = new Manager(target);
		
		DepartmentFilter df = new DepartmentFilter();
		RoleFilter rf = new RoleFilter();
		ExperienceFilter ef = new ExperienceFilter();
		SalaryFilter sf = new SalaryFilter();
		SkillsFilter skillF = new SkillsFilter();
		Client client = new Client();
		client.setManager(manager);
		manager.setFilter(df);
		client.sendRequest("t",employees);
		manager.setFilter(rf);
		client.sendRequest("nv",employees);
		manager.setFilter(ef);
		client.sendRequest("5nam",employees);
		manager.setFilter(sf);
		client.sendRequest("1000",employees);
		manager.setFilter(skillF);
		client.sendRequest("0",employees);
		
		
	}
}
