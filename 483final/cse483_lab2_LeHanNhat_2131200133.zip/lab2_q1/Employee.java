package lab2_q1;

public class Employee {
	private String name;
	private String department;
	private String role;
	private String experience;
	private String salary;
	private String skills;
	public Employee(String name, String department, String role, String experience, String salary, String skills) {
		super();
		this.name = name;
		this.department = department;
		this.role = role;
		this.experience = experience;
		this.salary = salary;
		this.skills = skills;
	}
	public String getName() {
		return name;
	}
	public String getDepartment() {
		return department;
	}
	public String getRole() {
		return role;
	}
	public String getExperience() {
		return experience;
	}
	public String getSalary() {
		return salary;
	}
	public String getSkills() {
		return skills;
	}
	@Override
	public String toString() {
		
		return "Employee: " + this.name +" "+ this.department +" "+ this.role +" "+ this.experience+" "+this.salary+" "+this.skills;
				
	}
	
}
