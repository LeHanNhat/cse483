package lab2_q1;

import java.util.ArrayList;

public interface Filtered {
	public void meetFiltered(ArrayList<Employee> employees, String request);
}
