package lab2_q1;


import java.util.ArrayList;

public class Chain {
	private ArrayList<Filtered> filters = new ArrayList<Filtered>();;
	private Target target;

	public Chain() {
		super();
	}
	public void addFilters (Filtered filter) {
		filters.add(filter);
	}
	
	public void execute(String request,ArrayList<Employee> allEmployees) {
		
		for(Filtered f : filters ) {
			f.meetFiltered(allEmployees, request);
			
		}
		target.execute(request);
	}
	public void setTarget (Target target) {
		this.target = target;
	}
}	
