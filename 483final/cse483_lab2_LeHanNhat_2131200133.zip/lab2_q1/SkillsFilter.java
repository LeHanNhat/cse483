package lab2_q1;

import java.util.ArrayList;

public class SkillsFilter implements Filtered {

	@Override
	public void meetFiltered(ArrayList<Employee> employees, String request) {
		// TODO Auto-generated method stub
		ArrayList<Employee> skillsEm = new ArrayList<Employee>();
		for (Employee em : employees) {
			if(em.getSkills()==request) {
				skillsEm.add(em);
			}
		}
		System.out.println(skillsEm);
	}

}
