package lab2_q1;

import java.util.ArrayList;

public class Manager {
	private Chain filterChain;
	
	public Manager(Target target) {
		filterChain = new  Chain();
		filterChain.setTarget(target);
	}
	public void setFilter(Filtered filter) {
		filterChain.addFilters(filter);
	}
	public void filterRequest(String request,ArrayList<Employee> allEmployees) {
		filterChain.execute(request,allEmployees);
	}
}
