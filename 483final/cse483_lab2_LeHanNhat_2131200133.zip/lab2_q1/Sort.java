package lab2_q1;

public interface Sort {

}
