package lab2_q2;

import java.util.ArrayList;

public class Manager {
	private UserService us;
	private OrderService os;
	private PaymentService ps;
	public User user;
	public ArrayList<User> userList;
	public ArrayList<Product> productList;
	
	
	
	public Manager(UserService us, OrderService os, PaymentService ps, User user, ArrayList<User> userList,
			ArrayList<Product> productList) {
		
		this.us = us;
		this.os = os;
		this.ps = ps;
		this.user = user;
		this.userList = userList;
		this.productList = productList;
	}
	public void SETTER1(UserService us  ) {
		this.us = us;
		
		
	}
	public void SETTER2(OrderService os) {
		this.os = os;
	}
	public void SETTER3(PaymentService ps) {
		this.ps = ps;
	}
	public void transfer1() {
		this.us.authenticateUser(user , userList);
		
	}
	public void transfer2() {
		
		this.os.placeOrder(user.getUserName(),productList);
		
	}
	public void transfer3() {
		
		this.ps.processPayment(user.getUserName(),productList);
	}
	
}
