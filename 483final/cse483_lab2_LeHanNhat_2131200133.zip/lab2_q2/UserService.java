package lab2_q2;

import java.util.ArrayList;

public interface UserService {
	
	public void authenticateUser(User user, ArrayList<User> userList);
}
