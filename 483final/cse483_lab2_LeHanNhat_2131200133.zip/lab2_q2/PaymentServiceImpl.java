package lab2_q2;

import java.util.ArrayList;

public class PaymentServiceImpl implements PaymentService {
	public int price ;
	
	
	
	public PaymentServiceImpl( ) {
		
		this.price = 0;
		
	}


	@Override
	public void processPayment(String userName, ArrayList<Product> productList ) {
		System.out.println("Total price for "+userName+": ");
		for(int i =0; i < productList.size();i++ ) {
			price+=productList.get(i).getPrice();
		}
		System.err.println(price);
	}
	

}
