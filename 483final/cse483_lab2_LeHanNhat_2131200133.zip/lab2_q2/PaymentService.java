package lab2_q2;

import java.util.ArrayList;

public interface PaymentService {
	public void processPayment(String userName, ArrayList<Product> productList );
}
