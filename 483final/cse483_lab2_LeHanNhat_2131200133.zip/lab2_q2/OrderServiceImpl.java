package lab2_q2;

import java.util.ArrayList;

public class OrderServiceImpl implements OrderService {
	

	@Override
	public void placeOrder(String userName, ArrayList<Product> productList) {
		// TODO Auto-generated method stub
		System.out.println(userName+" want:");
		for(int i =0; i < productList.size();i++ ) {
			System.out.println(productList.get(i).getName()+" ");
		}
	}

	

	


}
