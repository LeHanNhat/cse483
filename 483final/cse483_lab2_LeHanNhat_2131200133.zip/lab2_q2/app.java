package lab2_q2;

import java.util.ArrayList;
import java.util.Scanner;



public class app {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		ArrayList<User> userList = new ArrayList<User>();
		User user1 = new User("nhat", "123");
		User user2 = new User("duy", "123");
		User user3 = new User("bao", "12345");
		User user4 = new User("dat", "123");
		userList.add(user1);
		userList.add(user2);
		userList.add(user3);
		userList.add(user4);
		
		ArrayList<Product> productList = new ArrayList<Product>();
		
		Product pd1 = new Product("1", "Cake", 200);
		Product pd2 = new Product("2", "Chicken", 150);
		Product pd3 = new Product("3", "pizza", 300);
		
		productList.add(pd1);
		productList.add(pd2);
		productList.add(pd3);
		
		UserService us = new UserServiceImpl();
		OrderService os = new OrderServiceImpl();
		PaymentService ps = new PaymentServiceImpl();
		
		Manager manager = new Manager(us, os, ps, new User("bao", "12345"),userList,productList);
		


        System.out.println("Enter your choice ");
        String bankType = sc.nextLine();

       switch (bankType.toUpperCase()) {
          case "LOGIN":
        	   	 manager.SETTER1(us);
        	   	 manager.transfer1();
        	   	 break;
          case "ORDER":
        	  	 manager.SETTER2(os);
        	  	 manager.transfer2();
        	  	 break;
               
          case "PAYMENT":
        	  	 manager.SETTER3(ps);
        	  	 manager.transfer3();
	             break;
        	  	 
          default:
                  System.out.print("Wrong command");
         }
	}
}
