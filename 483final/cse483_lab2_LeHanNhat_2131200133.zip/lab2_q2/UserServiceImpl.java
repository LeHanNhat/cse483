package lab2_q2;

import java.util.ArrayList;

public class UserServiceImpl implements UserService {
	

	@Override
	public void authenticateUser(User user, ArrayList<User> userList) {
		// TODO Auto-generated method stub
		
			System.out.println("Welcome "+ user.getUserName());
			
		
			
	}

	

	
	
}
