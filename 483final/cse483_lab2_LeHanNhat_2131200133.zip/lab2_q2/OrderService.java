package lab2_q2;

import java.util.ArrayList;

public interface OrderService {
	public void placeOrder(String userName ,ArrayList<Product> productList);
}
