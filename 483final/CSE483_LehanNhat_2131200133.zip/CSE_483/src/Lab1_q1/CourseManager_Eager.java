package Lab1_q1;

import java.util.ArrayList;

public class CourseManager_Eager {
	private static CourseManager_Eager instance;
	private static ArrayList<Student> listStudent;
	private static ArrayList<Course> listCourse;
	private static ArrayList<Registration> listRegistration;

	private CourseManager_Eager() {

	}

	private static CourseManager_Eager getInstances() {
		instance = new CourseManager_Eager();
		listStudent = new ArrayList<Student>();
		listCourse = new ArrayList<Course>();
		listRegistration = new ArrayList<Registration>();
		return instance;
	}

	public void addingStudent(Student student) {
		if (listStudent.contains(student)) {
			System.out.println("Student existed");
		} else {
			listStudent.add(student);
		}
	}

	public void removingStudent(Student student) {
		if (listStudent.contains(student)) {
			listStudent.remove(student);
			System.out.println("Student remove succesfully");
		} else {
			System.out.println("Don't have this student in the system to remove");
		}
	}

	public void addingCourse(Course course) {
		if (listCourse.contains(course)) {
			System.out.println("Course existed");
		} else {
			listCourse.add(course);
		}
	}

	public void removingCourse(Course course) {
		if (listCourse.contains(course)) {
			listCourse.remove(course);
			System.out.println("Student remove succesfully");
		} else {
			System.out.println("Don't have this student in the system to remove");
		}
	}

	public void registering(Student student, Course course) {
		Registration registration = new Registration(student, course);
		if (listRegistration.contains(registration)) {
			System.out.println("Student has registered this course");
		} else {
			listRegistration.add(registration);
		}
	}

	public void unregistering(Student student, Course course) {
		Registration registration = new Registration(student, course);
		if (listRegistration.contains(registration)) {
			listRegistration.remove(registration);
		} else {
			System.out.println("Student has not registered this course");
		}
	}
}
