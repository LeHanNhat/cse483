package Lab1_q1;

import java.util.ArrayList;
import java.util.Hashtable;

public class Registration {
	public Student student;
	public Course course;
	public Registration(Student student, Course course) {
		
		this.student = student;
		this.course = course;
	}
	
	
	
}
