package Lab1_q2;

import java.util.Scanner;

public class client {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		FileWriterFacade facade = new FileWriterFacade();
		facade.start();
	}

}
