package Lab1_q2;

public class CompressionCodec {
	
	public void compressMenu() {
		System.out.println("Choose Compress option");
		System.out.println("\t1. Gzip \n");
		System.out.println("\t2. Bzip2 ");
	}
	public void compressionOption(String option) {
		System.out.println("Your data compression using " + option);
	}
	
}
