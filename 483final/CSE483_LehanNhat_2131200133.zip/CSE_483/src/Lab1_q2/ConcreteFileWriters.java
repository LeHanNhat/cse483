package Lab1_q2;

public class ConcreteFileWriters {
	public CompressionCodec compression;
	public EncryptionCodec encryption;
	public FileWriterFactory format;
	
	public ConcreteFileWriters() {
		
		this.compression = new CompressionCodec();
		this.encryption = new EncryptionCodec();
		this.format = new FileWriterFactory();
	}
	public void getCompressionMenu() {
		compression.compressMenu();
	}
	public void getEncryptionmenu() {
		encryption.encryptionMenu();
	}
	public void getFileFormatMenu() {
		format.fileFormatMenu();
	}
	public void writeData(String option1, String option2, String option3) {
		compression.compressionOption(option1);
		encryption.encryptionOption(option2);
		format.fileWritersOption(option3);
	}
	
	
}
