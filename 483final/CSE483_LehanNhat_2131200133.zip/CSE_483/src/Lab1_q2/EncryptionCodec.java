package Lab1_q2;

public class EncryptionCodec {
	
	public void encryptionMenu() {
		System.out.println("Choose Encryption option");
		System.out.println("\t1. AES \n");
		System.out.println("\t2. DES ");
	}
	public void encryptionOption(String option) {
		System.out.println("Your data Encryption using "+option);
	}
	
}
