package Lab1_q2;

import java.util.Scanner;

public class FileWriterFacade {
	
	private ConcreteFileWriters concreteFileWriters;
	private Scanner sc = new Scanner(System.in);
	public FileWriterFacade() {
		concreteFileWriters = new ConcreteFileWriters();
	}
	
	public void start() {
		concreteFileWriters.getFileFormatMenu();
		String option1 = sc.nextLine();
		concreteFileWriters.getCompressionMenu();
		String option2 = sc.nextLine();
		concreteFileWriters.getEncryptionmenu();
		String option3 = sc.nextLine();
		concreteFileWriters.writeData(option2, option3, option1);
		System.out.println("Processing data successfull ");
	}
	
	
}
