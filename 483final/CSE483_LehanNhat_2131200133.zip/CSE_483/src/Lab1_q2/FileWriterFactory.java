package Lab1_q2;

public class FileWriterFactory {
	public void fileFormatMenu() {
		System.out.println("Choose File Format option");
		System.out.println("\t1. CSV \n");
		System.out.println("\t2. JSON \n ");
		System.out.println("\t2. XML \n ");
	}
	public void fileWritersOption(String option) {
		System.out.println("This is "+option+" format");
	}
}
